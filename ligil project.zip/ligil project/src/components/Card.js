import React, { useState, useEffect } from "react";

function Card({ datas }) {
  const [show, setShow] = useState(false);
  const [bName, setBname] = useState("Showmore");
  const [page, setPage] = useState([]);
  const showmore = () => {
    setPage(...datas);

    setShow(!show);

    if (!show) {
      setBname("show less");
    } else {
      setBname("showmore");
    }
  };
  return (
    <div>
      {datas.map((data, i) => {
        return (
          <div
            style={{
              border: "2px black solid",
              display: "flex",
              flexDirection: "column",
              lineHeight: "3px",
              width: "65%",
              justifyContent: "center",
            }}
            key={i}
          >
            <h1>{i + 1}</h1>
            <h4>TITLE : {data.title}</h4>

            <h4>COMMENT : {data.comment}</h4>

            <h4
              style={
                data.friend_type === "friend"
                  ? { visibility: "block" }
                  : { display: "none" }
              }
            >
              NAME
            </h4>

            <h4
              style={
                data.friend_type === "friend"
                  ? { visibility: "block" }
                  : { display: "none" }
              }
            >
              {data.reviewer.name}
            </h4>

            <h4>
              OVERALL: {data.ratings.Overall}
              <i class="fa fa-star" aria-hidden="true"></i>
              {show ? (
                <div>
                  <h4>DELIVERY TIME : {data.ratings.delivery_time}</h4>

                  <h4>
                    DISCOUNT AND OFFERS :{data.ratings.discounts_and_offers}
                  </h4>
                  <h4>
                    MATCHES DECRIPTION :{data.ratings.matches_description}
                  </h4>

                  <h4>MATCHES PHOTO :{data.ratings.matches_photo}</h4>

                  <h4>PACKAGING : {data.ratings.packaging}</h4>

                  <h4>PRICE :{data.ratings.price}</h4>
                </div>
              ) : (
                " "
              )}
            </h4>
            <button onClick={() => showmore(i)}>{bName}</button>
          </div>
        );
      })}
    </div>
  );
}

export default Card;
