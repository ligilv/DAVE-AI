import React, { useState, useEffect } from "react";
import Product from "./get";
function Dropdown() {
  const [value, setValue] = useState([]);
  const [id, setId] = useState();
  const [viewID, setViewId] = useState([]);
  const [vId, setVId] = useState(1);
  var arr1 = [];
  var arr2 = [];
  useEffect(() => {
    const inloop = () => {
      for (let i = 1; i <= 20; i++) {
        arr1.push(i);
        setValue([...value, ...arr1]);
      }
    };

    inloop();
  }, []);
  const selectedProduct = (e) => {
    setId(e.target.value);
  };
  useEffect(() => {
    const inloop1 = () => {
      for (let i = 1; i <= 25; i++) {
        arr2.push(i);
        setViewId([...viewID, ...arr2]);
      }
    };

    inloop1();
  }, []);
  const selectedView = (e) => {
    setVId(e.target.value);
  };

  return (
    <div style={{ background: "silver" }}>
      <div
        style={{
          background: "grey",
          width: "65%",
          display: "flex",
          justifyContent: "space-between",
        }}
      >
        Select Product ID
        <select onClick={selectedProduct}>
          {value.map((k, i) => {
            return (
              <option key={i} value={k}>
                {k}
              </option>
            );
          })}
        </select>
        Select View ID
        <select onClick={selectedView}>
          {viewID.map((k, i) => {
            return (
              <option key={i} value={k}>
                {k}
              </option>
            );
          })}
        </select>
      </div>
      <Product ProductId={id} ViewId={vId} />
    </div>
  );
}

export default Dropdown;
