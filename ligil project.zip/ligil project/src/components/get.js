import React, { useEffect, useState } from "react";
import axios from "axios";
import Card from "./Card";
function Product({ ProductId, ViewId }) {
  const [title, setTitle] = useState("");
  const [datas, setdata] = useState([]);
  const Search = () => {
    axios
      .get(`http://www.i2ce.in/reviews/${ProductId}/${ViewId}`)
      .then((data) => {
        setdata(data.data.reviews);
      });
  };
  return (
    <div>
      <button onClick={Search}>Search</button>

      <Card datas={datas} />
    </div>
  );
}

export default Product;
