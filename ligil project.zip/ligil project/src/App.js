import React, { useState } from "react";
import "./App.css";
import Dropdown from "./components/Dropdown";
import Product from "./components/get";
function App() {
  return (
    <div className="App">
      <Dropdown />
    </div>
  );
}

export default App;
